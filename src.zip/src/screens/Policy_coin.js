import React, { Component } from 'react';
import { View, Text, Image, TouchableHighlight } from 'react-native';
import axios from 'axios';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import stringsoflanguages from './stringsoflanguages';

class Policy_coin extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data_text: ''
        };
    }
    componentDidMount() {
        this.test1()

    }

    test1() {
        fetch('http://chavalitapp.revocloudserver.com/chavalit_backoffice/api/function.php?fnc=get_coin_condition_text')
            .then((response) => response.json())
            .then((responseJson) => {

                this.setState({
                    isLoading: false,
                    data_text: responseJson
                }, function () {
                    console.log(this.state.data_text)
                });
            })

            .catch((error) => {
                console.error(error);
            });

    }

    render() {
        return (
            <View style={{
                backgroundColor: 'white',
                flex: 1
            }}>

                <View style={{
                    backgroundColor: '#F06823',
                    height: '11%'
                }}>


                    <TouchableHighlight
                        underlayColor={"#C5C6D0"}
                        onPress={() => this.props.navigation.goBack()}
                        style={{
                            height: 25,
                            width: 50,
                            top: 25,
                            alignItems: 'center',

                        }}>
                        <Image
                            resizeMode='contain'
                            style={{
                                width: 50,
                                height: 22,
                                alignItems: 'center',


                            }}
                            source={require("../imgs/leftarrow.png")}></Image>
                    </TouchableHighlight>
                    <Text
                        style={{

                            color: 'white',
                            fontSize: 18,
                            textAlign: 'auto',
                            left: 45,
                            bottom: 2,
                            fontFamily:'Prompt-Bold'

                        }}>{stringsoflanguages.p31}</Text>
                </View>



                <Text style={{ fontSize: 18, margin: 20, fontFamily:'Prompt-Light' }}>  
                 {this.state.data_text.coin_condition_text}
                 </Text>



            </View>

        );
    }
}

export default Policy_coin;
